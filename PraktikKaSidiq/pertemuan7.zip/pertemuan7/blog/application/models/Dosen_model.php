<?php
class Dosen_model extends CI_Model {
    // Buat Property atau Variabel
    public $nidn;
    public $pendidikan;
}
?>